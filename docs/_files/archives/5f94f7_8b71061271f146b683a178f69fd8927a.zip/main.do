*"Decomposing Supply and Demand Driven Inflation"
*Adam Hale Shapiro, Federal Reserve Bank of San Francisco 

*************************************************************************************************************

***Rolling-window Headline***
global foodenergy = 1  /* 1 is headline, 0 is core */
global smooth     = 0  /* 0 no residual smoothing (baseline). choosing $smooth = {2,3,4} averages the last $smooth residuals  */
global thresh1    = 0  /* 0 is no ambiguous category. $thresh1 0.1 will povide the ambigous threshold set in the paper*/
global lag        = 12 /* number of lags in VAR */
global weight     = 0  /* parametric distribution to weight categories (see paper's appendix), 0 is baseline, 1 is parametric*/
global firstdiff  = 0  /*defines the VAR to be in first-differences, 0 is baseline, 1 is first-differences*/
global level      = 1  /*the level of aggregation of BEA's categories, 1 is baseline */
global trend      = 0  /*includes a 3rd order polynomial trend in the VAR, 0 is no trend, 1 is trend */
global cumul      = 1  /*distance of the impulse response horizon (h) in the VAR*/
global quarterly  = 0  /*aggregation of frequency, 0 is monthly, 1 is quarterly*/
global hamilton   = 0 /* includes the Hamilton (2018) filter before running estimation, 0 is no filter, 1 is filter*/
do  main_construct.do
save "...\decomp_head_noambig.dta", replace


***Rolling-window Core***
global foodenergy = 0
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_core_noambig.dta", replace


***Rolling-window Headline***(3-Lag VAR)
global foodenergy = 1
global smooth     = 0
global thresh1    = 0
global lag        = 3
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_head_noambig3.dta", replace


***Rolling-window Core***(3-Lag VAR)
global foodenergy = 0
global smooth     = 0
global thresh1    = 0
global lag        = 3
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_core_noambig3.dta", replace


***Rolling-window Headline***(24-Lag VAR)
global foodenergy = 1
global smooth     = 0
global thresh1    = 0
global lag        = 24
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_head_noambig24.dta", replace


***Rolling-window Core***(24-Lag VAR)
global foodenergy = 0
global smooth     = 0
global thresh1    = 0
global lag        = 24
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_core_noambig24.dta", replace



***Rolling-window Headline***(Smooth residuals, 3)
global foodenergy = 1
global smooth     = 3
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_head_noambig_smooth3.dta", replace


***Rolling-window Core***(Smooth residuals, 3)
global foodenergy = 0
global smooth     = 3
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_core_noambig_smooth3.dta", replace


***Rolling-window Headline***(First-differences)
global foodenergy = 1
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 1
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_head_noambig_fd.dta", replace


***Rolling-window Core***(First-differences)
global foodenergy = 0
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 1
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_core_noambig_fd.dta", replace




***Rolling-window Headline (Quarterly)***
global foodenergy = 1
global smooth     = 0
global thresh1    = 0
global lag        = 4
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 1
global hamilton   = 0
do  main_construct.do
save "...\decomp_head_noambig_Q.dta", replace


***Rolling-window Core (Quarterly)***
global foodenergy = 0
global smooth     = 0
global thresh1    = 0
global lag        = 4
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 1
global hamilton   = 0
do  main_construct.do
save "...\decomp_core_noambig_Q.dta", replace


***Rolling-window Headline*** Cumulative residuals (t-2) as dependent variable
global foodenergy = 1
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 2
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_head_noambig_cum2.dta", replace


***Rolling-window Core*** Cumulative residuals (t-2) as dependent variable
global foodenergy = 0
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 2
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_core_noambig_cum2.dta", replace



***Rolling-window Headline*** Cumulative residuals (t-3) as dependent variable
global foodenergy = 1
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 3
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_head_noambig_cum3.dta", replace


***Rolling-window Core*** Cumulative residuals (t-3) as dependent variable
global foodenergy = 0
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 3
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_core_noambig_cum3.dta", replace


***Rolling-window Headline (precision)***
global foodenergy = 1
global smooth     = 0
global thresh1    = 0.10
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\\decomp_head_10.dta", replace
***Rolling-window Core   (precision)***
global foodenergy = 0
global smooth     = 0
global thresh1    = 0.10
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_core_10.dta", replace

***Rolling-window Headline (with trend)***
global foodenergy = 1
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 1
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_head_noambig_trend.dta", replace

***Rolling-window Core (with trend)***
global foodenergy = 0
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 1
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_core_noambig_trend.dta", replace

***Rolling-window Headline (with Hamilton Filter)***
global foodenergy = 1
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 1
do  main_construct.do
save "...\decomp_head_noambig_ham.dta", replace


***Rolling-window Core (with Hamilton Filter)***
global foodenergy = 1
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 1
do  main_construct.do
save "...\decomp_core_noambig_ham.dta", replace


***Rolling-window Headline GOODS/SERVICES***
global foodenergy = 1
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct_goodsserv.do
save "...\decomp_head_noambig_gs.dta", replace

***Rolling-window Core GOODS/SERVICES***
global foodenergy = 0
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct_goodsserv.do
save "...\decomp_core_noambig_gs.dta", replace


***Rolling-window Headline (granular)***
global foodenergy = 1
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 2
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_head_noambig_gran.dta", replace

***Rolling-window Core (granular)***
global foodenergy = 0
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 0
global firstdiff  = 0
global level      = 2
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_core_noambig_gran.dta", replace

***Weighted Labels (normal distribution)******
global foodenergy = 1
global smooth     = 0
global thresh1    = 0
global lag        = 12
global weight     = 1
global firstdiff  = 0
global level      = 1
global trend      = 0
global cumul      = 1
global quarterly  = 0
global hamilton   = 0
do  main_construct.do
save "...\decomp_head_weight.dta", replace
