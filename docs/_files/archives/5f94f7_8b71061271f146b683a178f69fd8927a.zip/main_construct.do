
clear all
set more off
cap log close
capture set haverdir M:\Haver\DLX\DATA


*t-stat threshold
local thresh2 0.15
local thresh3 0.30

*Regression sample
if ($level == 0 |$level == 1) {
	if $quarterly == 0 {
local min_date 1969m1
	}
	if $quarterly == 1 {
local min_date 1969q1
	}
}

if $level == 2 {
	if $quarterly == 0 {
local min_date 1998m1
	}
	if $quarterly == 1 {
local min_date 1998q1
	}
}


if $level == 0 {
if $foodenergy == 0 { 
import haver /*
       */ (GSCPI)@SURVEYS (CM CXFEM JCM JCXFEM YPM YPDM JCGXFEM JCSXEM CGXFEM CSXEM )@USNA  (CSENT LR YPLTPMH FGZPR FGZEBP FGZCS F10FED SEPUI CCIN SP500 FFEDTAR FCM10 FCM5 FCM30 FCM3M PZTEXP RECESSM)@USECON (IP CUT)@IP /*
	   Motor vehiccles */ CDVM@USNA /*
	   Furnishings */ CDFDM@USNA /*
	   Recreational Goods */ CDRGM@USNA /*
	   Other durable goods */ CDOM@USNA /*
	   Clothing & Footwear */ CNLM@USNA /*
	   Other nondurables */ CNOOM@USNA /*
	   Housing */ CSRM@USNA /*
	   water  */ CSLSM@USNA /*
	   Healthcare */ CSDM@USNA /*
	   Transportation */ CSTM@USNA /*
	   Recreational Services */ CSREM@USNA /*
	   Food services & acc */ CSFCM@USNA /*
	   Financial services */ CSNM@USNA /*
	   Other services */ CSOM@USNA /*
	   NPISH */ NPCFM@USNA /*
	 
	  Motor vehiccles */ CDVQM@USNA /*
	   Furnishings */ CDFDQM@USNA /*
	   Recreational Goods */ CDRGQM@USNA /*
	   Other durable goods */ CDOQM@USNA /*
	   Clothing & Footwear */ CNLQM@USNA /*
	   Other nondurables */ CNOOQM@USNA /*
	   Housing */ CSRQM@USNA /*
	   water  */ CSLSQM@USNA /*
	   Healthcare */ CSDQM@USNA /*
	   Transportation */ CSTQM@USNA /*
	   Recreational Services */ CSREQM@USNA /*
	   Food services & acc */ CSFCQM@USNA /*
	   Financial services */ CSNQM@USNA /*
	   Other services */ CSOQM@USNA /*
	   NPISH */ NPCFQM@USNA /*
	 
	   Motor vehiccles */ JCDVM@USNA /*
	   Furnishings */ JCDFDM@USNA /*
	   Recreational Goods */ JCDRGM@USNA /*
	   Other durable goods */ JCDOM@USNA /*
	   Clothing & Footwear */ JCNLM@USNA /*
	   Other nondurables */ JCNOOM@USNA /*
	   Housing */ JCSRM@USNA /*
	   water */ JCSLSM@USNA /* 
	   Healthcare */ JCSDM@USNA /*
	   Transportation */ JCSTM@USNA /*
	   Recreational Services */ JCSREM@USNA /*
	   Food services & acc */ JCSFCM@USNA /*
	   Financial services */ JCSNM@USNA /*
	   Other services */ JCSOM@USNA /*
	   NPISH */ JNPCFM@USNA, tvar(time_month)
	   }
if $foodenergy == 1 { 
import haver /*
       */ (GSCPI)@SURVEYS (CM CXFEM JCM JCXFEM YPM YPDM JCGXFEM JCSXEM CGXFEM CSXEM )@USNA  (CSENT LR YPLTPMH FGZPR FGZEBP FGZCS F10FED SEPUI CCIN SP500 FFEDTAR FCM10 FCM5 FCM30 FCM3M PZTEXP RECESSM)@USECON (IP CUT)@IP /*
	   Motor vehiccles */ CDVM@USNA /*
	   Food */ CNFOM@USNA /*
	   energy */ CNEM@USNA /*
	   Furnishings */ CDFDM@USNA /*
	   Recreational Goods */ CDRGM@USNA /*
	   Other durable goods */ CDOM@USNA /*
	   Clothing & Footwear */ CNLM@USNA /*
	   Other nondurables */ CNOOM@USNA /*
	   Housing */ CSRUM@USNA /*
	   Healthcare */ CSDM@USNA /*
	   Transportation */ CSTM@USNA /*
	   Recreational Services */ CSREM@USNA /*
	   Food services & acc */ CSFCM@USNA /*
	   Financial services */ CSNM@USNA /*
	   Other services */ CSOM@USNA /*
	   NPISH */ NPCFM@USNA /*
	   
	   
	   	Motor vehiccles */ CDVQM@USNA /*
	   Food */ CNFOQM@USNA /*
	   energy */ CNEQM@USNA /*
	   Furnishings */ CDFDQM@USNA /*
	   Recreational Goods */ CDRGQM@USNA /*
	   Other durable goods */ CDOQM@USNA /*
	   Clothing & Footwear */ CNLQM@USNA /*
	   Other nondurables */ CNOOQM@USNA /*
	   Housing */ CSRUQM@USNA /*
	   Healthcare */ CSDQM@USNA /*
	   Transportation */ CSTQM@USNA /*
	   Recreational Services */ CSREQM@USNA /*
	   Food services & acc */ CSFCQM@USNA /*
	   Financial services */ CSNQM@USNA /*
	   Other services */ CSOQM@USNA /*
	   NPISH */ NPCFQM@USNA /*
	   
	   Motor vehiccles */ JCDVM@USNA /*
	   Food */ JCNFOM@USNA /*
	   energy */ JCNEM@USNA /*
	   Furnishings */ JCDFDM@USNA /*
	   Recreational Goods */ JCDRGM@USNA /*
	   Other durable goods */ JCDOM@USNA /*
	   Clothing & Footwear */ JCNLM@USNA /*
	   Other nondurables */ JCNOOM@USNA /*
	   Housing */ JCSRUM@USNA /*
	   Healthcare */ JCSDM@USNA /*
	   Transportation */ JCSTM@USNA /*
	   Recreational Services */ JCSREM@USNA /*
	   Food services & acc */ JCSFCM@USNA /*
	   Financial services */ JCSNM@USNA /*
	   Other services */ JCSOM@USNA /*
	   NPISH */ JNPCFM@USNA, tvar(time_month)
	   }	   
}	  

if $level == 1 {
if $foodenergy == 1 { 	
*2nd level disaggregation
import haver /*
       */ (GSCPI)@SURVEYS (CM CXFEM JCM JCXFEM YPM YPDM JCGXFEM JCSXEM CGXFEM CSXEM )@USNA  (CSENT LR YPLTPMH FGZPR FGZEBP FGZCS F10FED SEPUI CCIN SP500 FFEDTAR FCM10 FCM5 FCM30 FCM3M PZTEXP RECESSM)@USECON (IP CUT)@IP /*
	   Consumption Expenditures */ /* 
		New motor vehicles */ CDMNM@USNA CDMTNM@USNA /*
		Net purchases of used motor vehicles */ CDMUM@USNA CDMTUM@USNA /*
		Motor vehicle parts and accessories */ CDMTTM@USNA CDMTVM@USNA /*
		Furniture and furnishings */ CDFUM@USNA CDFOLM@USNA CDFOFM@USNA CDFOTM@USNA /*
		Household appliances */ CDFKKM@USNA CDFKSM@USNA /*
		Glassware, tableware, and houeshold utensils */ CDFGDM@USNA CDFGKM@USNA /*
		Tools and equipment for house and garden */ CDFSTM@USNA CDFSLM@USNA /*
		Video, audio, photographic, and information processing equipment and media */ CDRGDM@USNA CDOWPM@USNA CDRGIM@USNA /*
		Sporting equipment, supplies, guns, and ammunition */ CDRSM@USNA /*
		Sports and recreational vehicles */ CDOWLM@USNA CDOWBM@USNA CDBBM@USNA /*
		Recreational books */ CDRBM@USNA /*
		Musical instruments */ CDFTIM@USNA /*
		Jewelry and watches */ CDOJJM@USNA CDOJWM@USNA /*
		Therapeutic appliances and equipment */ CDOOTM@USNA CDOOEM@USNA /*
		Educational books */ CDEBM@USNA /*
		Luggage and similar personal items */ CDOLM@USNA /*
		Telephone and facsimile equipment */ CDOTM@USNA /*
		Garments */ CNLFFM@USNA CNLMFM@USNA CNLFIM@USNA /*
		Other clothing materials and footwear */ CNLOLM@USNA CNLXIM@USNA CNLSM@USNA /*
		Pharmaceutical and other products */ CNODRM@USNA CNODOM@USNA /*
		Recreational items */ CNOGTM@USNA CNRPM@USNA CNGARM@USNA CNOGFM@USNA /*
		Household supplies */ CNOLPM@USNA CNOLFM@USNA CNOLNM@USNA CNOLSM@USNA CNOLOM@USNA /*
		Personal care products */ CNOPPM@USNA CNOPCM@USNA CNOPEM@USNA /*
		Tobacco */ CNOTM@USNA /*
		Magazines, newspapers, and stationery */ CNMGM@USNA CNONM@USNA /*
		Net expenditures abroad by U.S. residents */ CNOVUM@USNA CNOVRM@USNA /*
		Housing */ CSHTM@USNA CSRDM@USNA CSHRM@USNA CSHOM@USNA /*
		Household utilities */ CSLWSM@USNA CSLWRM@USNA CSLEM@USNA CSLGM@USNA  /*
		Outpatient services */ CSMPM@USNA CSMDM@USNA CSMOM@USNA /*
		Hospital and nursing home services */ CSMHPM@USNA CSMHNM@USNA /*
		Motor vehicle services */ CSTURM@USNA CSTRLM@USNA /*
		Public transportation */ CSTIGM@USNA CSTIPM@USNA CSTIWM@USNA /*
		Membership clubs, sports centers, parks, theaters and museums */ CSRCCM@USNA CSRCPM@USNA CSRSM@USNA CSOSLM@USNA /*
		***Audio-video, phographic, and information processing servicse */ CSREPM@USNA /*
		Gambling */ CSROGM@USNA CSROLM@USNA CSROBM@USNA /*
		Other recreational services */ CSROVM@USNA CSRKM@USNA CSREVM@USNA /*
		Food services */ CSFPM@USNA CSFEEM@USNA /*
		Accommodations */ CSHOTM@USNA CSHSM@USNA /*
		Financial services */ CSOBSM@USNA CSNFCM@USNA /*
		Insurance */ CSOBIM@USNA CSLIM@USNA CSMIM@USNA CSVIM@USNA /*
		***Communication */ CSLTPM@USNA /*
		Education services */ CSOEUM@USNA CSOEEM@USNA CSEOVM@USNA /*
		Professional and other services */ CSOBLM@USNA CSBOM@USNA CSBOUM@USNA CSBOPM@USNA CSOBFM@USNA /*
		Personal care and clothing services */ CSPPM@USNA CSOPLM@USNA /*
		Social services and religious activities */ CSSSCM@USNA CSSSWM@USNA CSSSVM@USNA CSSSRM@USNA CSSSFM@USNA /*
		Household maintenance */ CSLDM@USNA CSLOSM@USNA CSLORM@USNA CSLOPM@USNA CSLOOM@USNA /*
		Net foreign travel */ CSVTM@USNA CSVXM@USNA /*
		Nonprofit */ NPCFM@USNA /*
		
		New motor vehicles */ CDMNQM@USNA CDMTNQM@USNA /*
		Net purchases of used motor vehicles */ CDMUQM@USNA CDMTUQM@USNA /*
		Motor vehicle parts and accessories */ CDMTTQM@USNA CDMTVQM@USNA /*
		Furniture and furnishings */ CDFUQM@USNA CDFOLQM@USNA CDFOFQM@USNA CDFOTQM@USNA /*
		Household appliances */ CDFKKQM@USNA CDFKSQM@USNA /*
		Glassware, tableware, and houeshold utensils */ CDFGDQM@USNA CDFGKQM@USNA /*
		Tools and equipment for house and garden */ CDFSTQM@USNA CDFSLQM@USNA /*
		Video, audio, photographic, and information processing equipment and media */ CDRGDQM@USNA CDOWPQM@USNA CDRGIQM@USNA /*
		Sporting equipment, supplies, guns, and ammunition */ CDRSQM@USNA /*
		Sports and recreational vehicles */ CDOWLQM@USNA CDOWBQM@USNA CDBBQM@USNA /*
		Recreational books */ CDRBQM@USNA /*
		Musical instruments */ CDFTIQM@USNA /*
		Jewelry and watches */ CDOJJQM@USNA CDOJWQM@USNA /*
		Therapeutic appliances and equipment */ CDOOTQM@USNA CDOOEQM@USNA /*
		Educational books */ CDEBQM@USNA /*
		Luggage and similar personal items */ CDOLQM@USNA /*
		Telephone and facsimile equipment */ CDOTQM@USNA /*
		Garments */ CNLFFQM@USNA CNLMFQM@USNA CNLFIQM@USNA /*
		Other clothing materials and footwear */ CNLOLQM@USNA CNLXIQM@USNA CNLSQM@USNA /*
		Pharmaceutical and other products */ CNODRQM@USNA CNODOQM@USNA /*
		Recreational items */ CNOGTQM@USNA CNRPQM@USNA CNGARQM@USNA CNOGFQM@USNA /*
		Household supplies */ CNOLPQM@USNA CNOLFQM@USNA CNOLNQM@USNA CNOLSQM@USNA CNOLOQM@USNA /*
		Personal care products */ CNOPPQM@USNA CNOPCQM@USNA CNOPEQM@USNA /*
		Tobacco */ CNOTQM@USNA /*
		Magazines, newspapers, and stationery */ CNMGQM@USNA CNONQM@USNA /*
		Net expenditures abroad by U.S. residents */ CNOVUQM@USNA CNOVRQM@USNA /*
		Housing */ CSHTQM@USNA CSRDQM@USNA CSHRQM@USNA CSHOQM@USNA /*
		Household utilities */ CSLWSQM@USNA CSLWRQM@USNA CSLEQM@USNA CSLGQM@USNA  /*
		Outpatient services */ CSMPQM@USNA CSMDQM@USNA CSMOQM@USNA /*
		Hospital and nursing home services */ CSMHPQM@USNA CSMHNQM@USNA /*
		Motor vehicle services */ CSTURQM@USNA CSTRLQM@USNA /*
		Public transportation */ CSTIGQM@USNA CSTIPQM@USNA CSTIWQM@USNA /*
		Membership clubs, sports centers, parks, theaters and museums */ CSRCCQM@USNA CSRCPQM@USNA CSRSQM@USNA CSOSLQM@USNA /*
		**Audio-video, phographic, and information processing servicse */ CSREPQM@USNA /*
		Gambling */ CSROGQM@USNA CSROLQM@USNA CSROBQM@USNA /*
		Other recreational services */ CSROVQM@USNA CSRKQM@USNA CSREVQM@USNA /*
		Food services */ CSFPQM@USNA CSFEEQM@USNA /*
		Accommodations */ CSHOTQM@USNA CSHSQM@USNA /*
		Financial services */ CSOBSQM@USNA CSNFCQM@USNA /*
		Insurance */ CSOBIQM@USNA CSLIQM@USNA CSMIQM@USNA CSVIQM@USNA /*
		Communication */ CSLTPQM@USNA/*
		Education services */ CSOEUQM@USNA CSOEEQM@USNA CSEOVQM@USNA /*
		Professional and other services */ CSOBLQM@USNA CSBOQM@USNA CSBOUQM@USNA CSBOPQM@USNA CSOBFQM@USNA /*
		Personal care and clothing services */ CSPPQM@USNA CSOPLQM@USNA /*
		Social services and religious activities */ CSSSCQM@USNA CSSSWQM@USNA CSSSVQM@USNA CSSSRQM@USNA CSSSFQM@USNA /*
		Household maintenance */ CSLDQM@USNA CSLOSQM@USNA CSLORQM@USNA CSLOPQM@USNA CSLOOQM@USNA /*
		Net foreign travel */ CSVTQM@USNA CSVXQM@USNA /*
		Nonprofit */ NPCFQM@USNA /*
		
	Indeces */ /*
		New motor vehicles */ JCDMNM@USNA JCDMTNM@USNA /*
		Net purchases of used motor vehicles */ JCDMUM@USNA JCDMTUM@USNA /*
		Motor vehicle parts and accessories */ JCDMTTM@USNA JCDMTVM@USNA /*
		Furniture and furnishings */ JCDFUM@USNA JCDFOLM@USNA JCDFOFM@USNA JCDFOTM@USNA /*
		Household appliances */ JCDFKKM@USNA JCDFKSM@USNA /*
		Glassware, tableware, and houeshold utensils */ JCDFGDM@USNA JCDFGKM@USNA /*
		Tools and equipment for house and garden */ JCDFSTM@USNA JCDFSLM@USNA /*
		Video, audio, photographic, and information processing equipment and media */ JCDRGDM@USNA JCDOWPM@USNA JCDRGIM@USNA /*
		Sporting equipment, supplies, guns, and ammunition */ JCDRSM@USNA /*
		Sports and recreational vehicles */ JCDOWLM@USNA JCDOWBM@USNA JCDBBM@USNA /*
		Recreational books */ JCDRBM@USNA /*
		Musical instruments */ JCDFTIM@USNA /*
		Jewelry and watches */ JCDOJJM@USNA JCDOJWM@USNA /*
		Therapeutic appliances and equipment */ JCDOOTM@USNA JCDOOEM@USNA /*
		Educational books */ JCDEBM@USNA /*
		Luggage and similar personal items */ JCDOLM@USNA /*
		Telephone and facsimile equipment */ JCDOTM@USNA /*
		Garments */ JCNLFFM@USNA JCNLMFM@USNA JCNLFIM@USNA /*
		Other clothing materials and footwear */ JCNLOLM@USNA JCNLXIM@USNA JCNLSM@USNA /*
		Pharmaceutical and other products */ JCNODRM@USNA JCNODOM@USNA /*
		Recreational items */ JCNOGTM@USNA JCNRPM@USNA JCNGARM@USNA JCNOGFM@USNA /*
		Household supplies */ JCNOLPM@USNA JCNOLFM@USNA JCNOLNM@USNA JCNOLSM@USNA JCNOLOM@USNA /*
		Personal care products */ JCNOPPM@USNA JCNOPCM@USNA JCNOPEM@USNA /*
		Tobacco */ JCNOTM@USNA /*
		Magazines, newspapers, and stationery */ JCNMGM@USNA JCNONM@USNA /*
		Net expenditures abroad by U.S. residents */ JCNOVUM@USNA JCNOVRM@USNA /*
		Housing */ JCSHTM@USNA JCSRDM@USNA JCSHRM@USNA JCSHOM@USNA /*
		Household utilities */ JCSLWSM@USNA JCSLWRM@USNA JCSLEM@USNA JCSLGM@USNA /*
		Outpatient services */ JCSMPM@USNA JCSMDM@USNA JCSMOM@USNA /*
		Hospital and nursing home services */ JCSMHPM@USNA JCSMHNM@USNA /*
		Motor vehicle services */ JCSTURM@USNA JCSTRLM@USNA /*
		Public transportation */ JCSTIGM@USNA JCSTIPM@USNA JCSTIWM@USNA /*
		Membership clubs, sports centers, parks, theaters and museums */ JCSRCCM@USNA JCSRCPM@USNA JCSRSM@USNA JCSOSLM@USNA /*
		**Audio-video, phographic, and information processing servicse */ JCSREPM@USNA /*
		Gambling */ JCSROGM@USNA JCSROLM@USNA JCSROBM@USNA /*
		Other recreational services */ JCSROVM@USNA JCSRKM@USNA JCSREVM@USNA /*
		Food services */ JCSFPM@USNA JCSFEEM@USNA /*
		Accommodations */ JCSHOTM@USNA JCSHSM@USNA /*
		Financial services */ JCSOBSM@USNA JCSNFCM@USNA /*
		Insurance */ JCSOBIM@USNA JCSLIM@USNA JCSMIM@USNA JCSVIM@USNA /*
		***Communication */  JCSLTPM@USNA /*
		Education services */ JCSOEUM@USNA JCSOEEM@USNA JCSEOVM@USNA /*
		Professional and other services */ JCSOBLM@USNA JCSBOM@USNA JCSBOUM@USNA JCSBOPM@USNA JCSOBFM@USNA /*
		Personal care and clothing services */ JCSPPM@USNA JCSOPLM@USNA /*
		Social services and religious activities */ JCSSSCM@USNA JCSSSWM@USNA JCSSSVM@USNA JCSSSRM@USNA JCSSSFM@USNA /*
		Household maintenance */ JCSLDM@USNA JCSLOSM@USNA JCSLORM@USNA JCSLOPM@USNA JCSLOOM@USNA /*
		Net foreign travel */ JCSVTM@USNA JCSVXM@USNA /*
	    Nonprofit */ JNPCFM@USNA /*
	   Food and Energy */  /*
		Motor vehicle fuels, lubricants, and fluids */ CNLGOM@USNA CNLGLM@USNA /*
		Motor vehicle fuels, lubricants, and fluids */ JCNLGOM@USNA JCNLGLM@USNA  /*
		Motor vehicle fuels, lubricants, and fluids */ CNLGOQM@USNA CNLGLQM@USNA  /*
		Fuel oil and other fuels */ JCNOFUM@USNA JCNOFLM@USNA  /*
		Fuel oil and other fuels */ CNOFUM@USNA CNOFLM@USNA  /*
		Fuel oil and other fuels */ CNOFUQM@USNA CNOFLQM@USNA  /*
		Food and nonalcoholic beverages */ JCNFOFM@USNA JCNFONM@USNA  /*
		Food and nonalcoholic beverages */ CNFOFM@USNA CNFONM@USNA  /*
		Food and nonalcoholic beverages */ CNFOFQM@USNA CNFONQM@USNA  /*
		Alcoholic beverages */ JCNFOLDM@USNA JCNFOLEM@USNA JCNFOLBM@USNA  /*
		Alcoholic beverages */ CNFOLDM@USNA CNFOLEM@USNA CNFOLBM@USNA  /*
		Alcoholic beverages */ CNFOLDQM@USNA CNFOLEQM@USNA CNFOLBQM@USNA  /*
		Food produced and consumed on farms */ JCNFEFM@USNA  /*
		Food produced and consumed on farms */ CNFEFQM@USNA /*
		Food produced and consumed on farms */ CNFEFM@USNA , tvar(time_month)
}
else if $foodenergy == 0 { 
import haver /*
      */  (GSCPI)@SURVEYS (CM CXFEM JCM JCXFEM YPM YPDM JCGXFEM JCSXEM CGXFEM CSXEM )@USNA  (CSENT LR YPLTPMH FGZEBP FGZCS F10FED SEPUI CCIN FGZPR SP500 F10FED SEPUI CCIN SP500 FFEDTAR FCM10 FCM5 FCM30 FCM3M PZTEXP RECESSM)@USECON (IP CUT)@IP /*
	   Consumption Expenditures */ /* 
		New motor vehicles */ CDMNM@USNA CDMTNM@USNA /*
		Net purchases of used motor vehicles */ CDMUM@USNA CDMTUM@USNA /*
		Motor vehicle parts and accessories */ CDMTTM@USNA CDMTVM@USNA /*
		Furniture and furnishings */ CDFUM@USNA CDFOLM@USNA CDFOFM@USNA CDFOTM@USNA /*
		Household appliances */ CDFKKM@USNA CDFKSM@USNA /*
		Glassware, tableware, and houeshold utensils */ CDFGDM@USNA CDFGKM@USNA /*
		Tools and equipment for house and garden */ CDFSTM@USNA CDFSLM@USNA /*
		Video, audio, photographic, and information processing equipment and media */ CDRGDM@USNA CDOWPM@USNA CDRGIM@USNA /*
		Sporting equipment, supplies, guns, and ammunition */ CDRSM@USNA /*
		Sports and recreational vehicles */ CDOWLM@USNA CDOWBM@USNA CDBBM@USNA /*
		Recreational books */ CDRBM@USNA /*
		Musical instruments */ CDFTIM@USNA /*
		Jewelry and watches */ CDOJJM@USNA CDOJWM@USNA /*
		Therapeutic appliances and equipment */ CDOOTM@USNA CDOOEM@USNA /*
		Educational books */ CDEBM@USNA /*
		Luggage and similar personal items */ CDOLM@USNA /*
		Telephone and facsimile equipment */ CDOTM@USNA /*
		Garments */ CNLFFM@USNA CNLMFM@USNA CNLFIM@USNA /*
		Other clothing materials and footwear */ CNLOLM@USNA CNLXIM@USNA CNLSM@USNA /*
		Pharmaceutical and other products */ CNODRM@USNA CNODOM@USNA /*
		Recreational items */ CNOGTM@USNA CNRPM@USNA CNGARM@USNA CNOGFM@USNA /*
		Household supplies */ CNOLPM@USNA CNOLFM@USNA CNOLNM@USNA CNOLSM@USNA CNOLOM@USNA /*
		Personal care products */ CNOPPM@USNA CNOPCM@USNA CNOPEM@USNA /*
		Tobacco */ CNOTM@USNA /*
		Magazines, newspapers, and stationery */ CNMGM@USNA CNONM@USNA /*
		Net expenditures abroad by U.S. residents */ CNOVUM@USNA CNOVRM@USNA /*
		Housing */ CSHTM@USNA CSRDM@USNA CSHRM@USNA CSHOM@USNA /*
		Household utilities */ CSLWSM@USNA  CSLWRM@USNA /*
		Outpatient services */ CSMPM@USNA CSMDM@USNA CSMOM@USNA /*
		Hospital and nursing home services */ CSMHPM@USNA CSMHNM@USNA /*
		Motor vehicle services */ CSTURM@USNA CSTRLM@USNA /*
		Public transportation */ CSTIGM@USNA CSTIPM@USNA CSTIWM@USNA /*
		Membership clubs, sports centers, parks, theaters and museums */ CSRCCM@USNA CSRCPM@USNA CSRSM@USNA CSOSLM@USNA /*
		***Audio-video, phographic, and information processing servicse */ CSREPM@USNA /*
		Gambling */ CSROGM@USNA CSROLM@USNA CSROBM@USNA /*
		Other recreational services */ CSROVM@USNA CSRKM@USNA CSREVM@USNA /*
		Food services */ CSFPM@USNA CSFEEM@USNA /*
		Accommodations */ CSHOTM@USNA CSHSM@USNA /*
		Financial services */ CSOBSM@USNA CSNFCM@USNA /*
		Insurance */ CSOBIM@USNA CSLIM@USNA CSMIM@USNA CSVIM@USNA /*
		***Communication */ CSLTPM@USNA /*
		Education services */ CSOEUM@USNA CSOEEM@USNA CSEOVM@USNA /*
		Professional and other services */ CSOBLM@USNA CSBOM@USNA CSBOUM@USNA CSBOPM@USNA CSOBFM@USNA /*
		Personal care and clothing services */ CSPPM@USNA CSOPLM@USNA /*
		Social services and religious activities */ CSSSCM@USNA CSSSWM@USNA CSSSVM@USNA CSSSRM@USNA CSSSFM@USNA /*
		Household maintenance */ CSLDM@USNA CSLOSM@USNA CSLORM@USNA CSLOPM@USNA CSLOOM@USNA /*
		Net foreign travel */ CSVTM@USNA CSVXM@USNA /*
		Nonprofit */ NPCFM@USNA /*
		
		New motor vehicles */ CDMNQM@USNA CDMTNQM@USNA /*
		Net purchases of used motor vehicles */ CDMUQM@USNA CDMTUQM@USNA /*
		Motor vehicle parts and accessories */ CDMTTQM@USNA CDMTVQM@USNA /*
		Furniture and furnishings */ CDFUQM@USNA CDFOLQM@USNA CDFOFQM@USNA CDFOTQM@USNA /*
		Household appliances */ CDFKKQM@USNA CDFKSQM@USNA /*
		Glassware, tableware, and houeshold utensils */ CDFGDQM@USNA CDFGKQM@USNA /*
		Tools and equipment for house and garden */ CDFSTQM@USNA CDFSLQM@USNA /*
		Video, audio, photographic, and information processing equipment and media */ CDRGDQM@USNA CDOWPQM@USNA CDRGIQM@USNA /*
		Sporting equipment, supplies, guns, and ammunition */ CDRSQM@USNA /*
		Sports and recreational vehicles */ CDOWLQM@USNA CDOWBQM@USNA CDBBQM@USNA /*
		Recreational books */ CDRBQM@USNA /*
		Musical instruments */ CDFTIQM@USNA /*
		Jewelry and watches */ CDOJJQM@USNA CDOJWQM@USNA /*
		Therapeutic appliances and equipment */ CDOOTQM@USNA CDOOEQM@USNA /*
		Educational books */ CDEBQM@USNA /*
		Luggage and similar personal items */ CDOLQM@USNA /*
		Telephone and facsimile equipment */ CDOTQM@USNA /*
		Garments */ CNLFFQM@USNA CNLMFQM@USNA CNLFIQM@USNA /*
		Other clothing materials and footwear */ CNLOLQM@USNA CNLXIQM@USNA CNLSQM@USNA /*
		Pharmaceutical and other products */ CNODRQM@USNA CNODOQM@USNA /*
		Recreational items */ CNOGTQM@USNA CNRPQM@USNA CNGARQM@USNA CNOGFQM@USNA /*
		Household supplies */ CNOLPQM@USNA CNOLFQM@USNA CNOLNQM@USNA CNOLSQM@USNA CNOLOQM@USNA /*
		Personal care products */ CNOPPQM@USNA CNOPCQM@USNA CNOPEQM@USNA /*
		Tobacco */ CNOTQM@USNA /*
		Magazines, newspapers, and stationery */ CNMGQM@USNA CNONQM@USNA /*
		Net expenditures abroad by U.S. residents */ CNOVUQM@USNA CNOVRQM@USNA /*
		Housing */ CSHTQM@USNA CSRDQM@USNA CSHRQM@USNA CSHOQM@USNA /*
		Household utilities */ CSLWSQM@USNA  CSLWRQM@USNA  /*
		Outpatient services */ CSMPQM@USNA CSMDQM@USNA CSMOQM@USNA /*
		Hospital and nursing home services */ CSMHPQM@USNA CSMHNQM@USNA /*
		Motor vehicle services */ CSTURQM@USNA CSTRLQM@USNA /*
		Public transportation */ CSTIGQM@USNA CSTIPQM@USNA CSTIWQM@USNA /*
		Membership clubs, sports centers, parks, theaters and museums */ CSRCCQM@USNA CSRCPQM@USNA CSRSQM@USNA CSOSLQM@USNA /*
		***Audio-video, phographic, and information processing servicse */ CSREPQM@USNA /*
		Gambling */ CSROGQM@USNA CSROLQM@USNA CSROBQM@USNA /*
		Other recreational services */ CSROVQM@USNA CSRKQM@USNA CSREVQM@USNA /*
		Food services */ CSFPQM@USNA CSFEEQM@USNA /*
		Accommodations */ CSHOTQM@USNA CSHSQM@USNA /*
		Financial services */ CSOBSQM@USNA CSNFCQM@USNA /*
		Insurance */ CSOBIQM@USNA CSLIQM@USNA CSMIQM@USNA CSVIQM@USNA /*
		***Communication */ CSLTPQM@USNA /*
		Education services */ CSOEUQM@USNA CSOEEQM@USNA CSEOVQM@USNA /*
		Professional and other services */ CSOBLQM@USNA CSBOQM@USNA CSBOUQM@USNA CSBOPQM@USNA CSOBFQM@USNA /*
		Personal care and clothing services */ CSPPQM@USNA CSOPLQM@USNA /*
		Social services and religious activities */ CSSSCQM@USNA CSSSWQM@USNA CSSSVQM@USNA CSSSRQM@USNA CSSSFQM@USNA /*
		Household maintenance */ CSLDQM@USNA CSLOSQM@USNA CSLORQM@USNA CSLOPQM@USNA CSLOOQM@USNA /*
		Net foreign travel */ CSVTQM@USNA CSVXQM@USNA /*
		Nonprofit */ NPCFQM@USNA /*
		
	Indeces */ /*
		New motor vehicles */ JCDMNM@USNA JCDMTNM@USNA /*
		Net purchases of used motor vehicles */ JCDMUM@USNA JCDMTUM@USNA /*
		Motor vehicle parts and accessories */ JCDMTTM@USNA JCDMTVM@USNA /*
		Furniture and furnishings */ JCDFUM@USNA JCDFOLM@USNA JCDFOFM@USNA JCDFOTM@USNA /*
		Household appliances */ JCDFKKM@USNA JCDFKSM@USNA /*
		Glassware, tableware, and houeshold utensils */ JCDFGDM@USNA JCDFGKM@USNA /*
		Tools and equipment for house and garden */ JCDFSTM@USNA JCDFSLM@USNA /*
		Video, audio, photographic, and information processing equipment and media */ JCDRGDM@USNA JCDOWPM@USNA JCDRGIM@USNA /*
		Sporting equipment, supplies, guns, and ammunition */ JCDRSM@USNA /*
		Sports and recreational vehicles */ JCDOWLM@USNA JCDOWBM@USNA JCDBBM@USNA /*
		Recreational books */ JCDRBM@USNA /*
		Musical instruments */ JCDFTIM@USNA /*
		Jewelry and watches */ JCDOJJM@USNA JCDOJWM@USNA /*
		Therapeutic appliances and equipment */ JCDOOTM@USNA JCDOOEM@USNA /*
		Educational books */ JCDEBM@USNA /*
		Luggage and similar personal items */ JCDOLM@USNA /*
		Telephone and facsimile equipment */ JCDOTM@USNA /*
		Garments */ JCNLFFM@USNA JCNLMFM@USNA JCNLFIM@USNA /*
		Other clothing materials and footwear */ JCNLOLM@USNA JCNLXIM@USNA JCNLSM@USNA /*
		Pharmaceutical and other products */ JCNODRM@USNA JCNODOM@USNA /*
		Recreational items */ JCNOGTM@USNA JCNRPM@USNA JCNGARM@USNA JCNOGFM@USNA /*
		Household supplies */ JCNOLPM@USNA JCNOLFM@USNA JCNOLNM@USNA JCNOLSM@USNA JCNOLOM@USNA /*
		Personal care products */ JCNOPPM@USNA JCNOPCM@USNA JCNOPEM@USNA /*
		Tobacco */ JCNOTM@USNA /*
		Magazines, newspapers, and stationery */ JCNMGM@USNA JCNONM@USNA /*
		Net expenditures abroad by U.S. residents */ JCNOVUM@USNA JCNOVRM@USNA /*
		Housing */ JCSHTM@USNA JCSRDM@USNA JCSHRM@USNA JCSHOM@USNA /*
		Household utilities */ JCSLWSM@USNA  JCSLWRM@USNA /*
		Outpatient services */ JCSMPM@USNA JCSMDM@USNA JCSMOM@USNA /*
		Hospital and nursing home services */ JCSMHPM@USNA JCSMHNM@USNA /*
		Motor vehicle services */ JCSTURM@USNA JCSTRLM@USNA /*
		Public transportation */ JCSTIGM@USNA JCSTIPM@USNA JCSTIWM@USNA /*
		Membership clubs, sports centers, parks, theaters and museums */ JCSRCCM@USNA JCSRCPM@USNA JCSRSM@USNA JCSOSLM@USNA /*
		***Audio-video, phographic, and information processing servicse */ JCSREPM@USNA /*
		Gambling */ JCSROGM@USNA JCSROLM@USNA JCSROBM@USNA /*
		Other recreational services */ JCSROVM@USNA JCSRKM@USNA JCSREVM@USNA /*
		Food services */ JCSFPM@USNA JCSFEEM@USNA /*
		Accommodations */ JCSHOTM@USNA JCSHSM@USNA /*
		Financial services */ JCSOBSM@USNA JCSNFCM@USNA /*
		Insurance */ JCSOBIM@USNA JCSLIM@USNA JCSMIM@USNA JCSVIM@USNA /*
		***Communication */ JCSLTPM@USNA /*
		Education services */ JCSOEUM@USNA JCSOEEM@USNA JCSEOVM@USNA /*
		Professional and other services */ JCSOBLM@USNA JCSBOM@USNA JCSBOUM@USNA JCSBOPM@USNA JCSOBFM@USNA /*
		Personal care and clothing services */ JCSPPM@USNA JCSOPLM@USNA /*
		Social services and religious activities */ JCSSSCM@USNA JCSSSWM@USNA JCSSSVM@USNA JCSSSRM@USNA JCSSSFM@USNA /*
		Household maintenance */ JCSLDM@USNA JCSLOSM@USNA JCSLORM@USNA JCSLOPM@USNA JCSLOOM@USNA /*
		Net foreign travel */ JCSVTM@USNA JCSVXM@USNA /*
        Nonprofit */ JNPCFM@USNA, tvar(time_month) 
		}
}

if $level == 2 {
if $foodenergy == 1 { 	
*2nd level disaggregation
import haver /*
       */ (GSCPI)@SURVEYS (CM CXFEM JCM JCXFEM YPM YPDM JCGXFEM JCSXEM CGXFEM CSXEM )@USNA  (CSENT LR YPLTPMH FGZPR FGZEBP FGZCS F10FED SEPUI CCIN SP500 FFEDTAR FCM10 FCM5 FCM30 FCM3M PZTEXP RECESSM)@USECON (IP CUT)@IP /*
	   Consumption Expenditures */ /* 
		New motor vehicles */ CDMNM@USNA CDMTNM@USNA /*
		Net purchases of used motor vehicles */ CDMUM@USNA CDMTUM@USNA /*
		Motor vehicle parts and accessories */ CDMTTM@USNA CDMTVM@USNA /*
		Furniture and furnishings */ CDFUM@USNA CDFOLM@USNA CDFOFM@USNA CDFOTM@USNA /*
		Household appliances */ CDFKKM@USNA CDFKSM@USNA /*
		Glassware, tableware, and houeshold utensils */ CDFGDM@USNA CDFGKM@USNA /*
		Tools and equipment for house and garden */ CDFSTM@USNA CDFSLM@USNA /*
		Video, audio, photographic, and information processing equipment and media */ CDRGDM@USNA CDOWPM@USNA CDRGIM@USNA /*
		Sporting equipment, supplies, guns, and ammunition */ CDRSM@USNA /*
		Sports and recreational vehicles */ CDOWLM@USNA CDOWBM@USNA CDBBM@USNA /*
		Recreational books */ CDRBM@USNA /*
		Musical instruments */ CDFTIM@USNA /*
		Jewelry and watches */ CDOJJM@USNA CDOJWM@USNA /*
		Therapeutic appliances and equipment */ CDOOTM@USNA CDOOEM@USNA /*
		Educational books */ CDEBM@USNA /*
		Luggage and similar personal items */ CDOLM@USNA /*
		Telephone and facsimile equipment */ CDOTM@USNA /*
		Garments */ CNLFFM@USNA CNLMFM@USNA CNLFIM@USNA /*
		Other clothing materials and footwear */ CNLOLM@USNA CNLXIM@USNA CNLSM@USNA /*
		Pharmaceutical and other products */ CNODRM@USNA CNODOM@USNA /*
		Recreational items */ CNOGTM@USNA CNRPM@USNA CNGARM@USNA CNOGFM@USNA /*
		Household supplies */ CNOLPM@USNA CNOLFM@USNA CNOLNM@USNA CNOLSM@USNA CNOLOM@USNA /*
		Personal care products */ CNOPPM@USNA CNOPCM@USNA CNOPEM@USNA /*
		Tobacco */ CNOTM@USNA /*
		Magazines, newspapers, and stationery */ CNMGM@USNA CNONM@USNA /*
		Net expenditures abroad by U.S. residents */ CNOVUM@USNA CNOVRM@USNA /*
		Housing */ CSHTM@USNA CSRDM@USNA CSHRM@USNA CSHOM@USNA /*
		Household utilities */ CSLWSM@USNA CSLWRM@USNA CSLEM@USNA CSLGM@USNA  /*
		Outpatient services */ CSMPM@USNA CSMDM@USNA CSMOM@USNA /*
		Hospital and nursing home services */ CSMHPM@USNA CSMHNM@USNA /*
		Motor vehicle services */ CSTURM@USNA CSTRLM@USNA /*
		Public transportation */ CSTIGM@USNA CSTIPM@USNA CSTIWM@USNA /*
		Membership clubs, sports centers, parks, theaters and museums */ CSRCCM@USNA CSRCPM@USNA CSRSM@USNA CSOSLM@USNA /*
		Audio-video, phographic, and information processing servicse */ CSROTM@USNA CSRODM@USNA CSROUM@USNA CSREEM@USNA CSROYM@USNA /*
		Gambling */ CSROGM@USNA CSROLM@USNA CSROBM@USNA /*
		Other recreational services */ CSROVM@USNA CSRKM@USNA CSREVM@USNA /*
		Food services */ CSFPM@USNA CSFEEM@USNA /*
		Accommodations */ CSHOTM@USNA CSHSM@USNA /*
		Financial services */ CSOBSM@USNA CSNFCM@USNA /*
		Insurance */ CSOBIM@USNA CSLIM@USNA CSMIM@USNA CSVIM@USNA /*
		Communication */ CSLTNM@USNA CSLPM@USNA CSRJIM@USNA /*
		Education services */ CSOEUM@USNA CSOEEM@USNA CSEOVM@USNA /*
		Professional and other services */ CSOBLM@USNA CSBOM@USNA CSBOUM@USNA CSBOPM@USNA CSOBFM@USNA /*
		Personal care and clothing services */ CSPPM@USNA CSOPLM@USNA /*
		Social services and religious activities */ CSSSCM@USNA CSSSWM@USNA CSSSVM@USNA CSSSRM@USNA CSSSFM@USNA /*
		Household maintenance */ CSLDM@USNA CSLOSM@USNA CSLORM@USNA CSLOPM@USNA CSLOOM@USNA /*
		Net foreign travel */ CSVTM@USNA CSVXM@USNA /*
		Nonprofit */ NPCFM@USNA /*
		
		New motor vehicles */ CDMNQM@USNA CDMTNQM@USNA /*
		Net purchases of used motor vehicles */ CDMUQM@USNA CDMTUQM@USNA /*
		Motor vehicle parts and accessories */ CDMTTQM@USNA CDMTVQM@USNA /*
		Furniture and furnishings */ CDFUQM@USNA CDFOLQM@USNA CDFOFQM@USNA CDFOTQM@USNA /*
		Household appliances */ CDFKKQM@USNA CDFKSQM@USNA /*
		Glassware, tableware, and houeshold utensils */ CDFGDQM@USNA CDFGKQM@USNA /*
		Tools and equipment for house and garden */ CDFSTQM@USNA CDFSLQM@USNA /*
		Video, audio, photographic, and information processing equipment and media */ CDRGDQM@USNA CDOWPQM@USNA CDRGIQM@USNA /*
		Sporting equipment, supplies, guns, and ammunition */ CDRSQM@USNA /*
		Sports and recreational vehicles */ CDOWLQM@USNA CDOWBQM@USNA CDBBQM@USNA /*
		Recreational books */ CDRBQM@USNA /*
		Musical instruments */ CDFTIQM@USNA /*
		Jewelry and watches */ CDOJJQM@USNA CDOJWQM@USNA /*
		Therapeutic appliances and equipment */ CDOOTQM@USNA CDOOEQM@USNA /*
		Educational books */ CDEBQM@USNA /*
		Luggage and similar personal items */ CDOLQM@USNA /*
		Telephone and facsimile equipment */ CDOTQM@USNA /*
		Garments */ CNLFFQM@USNA CNLMFQM@USNA CNLFIQM@USNA /*
		Other clothing materials and footwear */ CNLOLQM@USNA CNLXIQM@USNA CNLSQM@USNA /*
		Pharmaceutical and other products */ CNODRQM@USNA CNODOQM@USNA /*
		Recreational items */ CNOGTQM@USNA CNRPQM@USNA CNGARQM@USNA CNOGFQM@USNA /*
		Household supplies */ CNOLPQM@USNA CNOLFQM@USNA CNOLNQM@USNA CNOLSQM@USNA CNOLOQM@USNA /*
		Personal care products */ CNOPPQM@USNA CNOPCQM@USNA CNOPEQM@USNA /*
		Tobacco */ CNOTQM@USNA /*
		Magazines, newspapers, and stationery */ CNMGQM@USNA CNONQM@USNA /*
		Net expenditures abroad by U.S. residents */ CNOVUQM@USNA CNOVRQM@USNA /*
		Housing */ CSHTQM@USNA CSRDQM@USNA CSHRQM@USNA CSHOQM@USNA /*
		Household utilities */ CSLWSQM@USNA CSLWRQM@USNA CSLEQM@USNA CSLGQM@USNA  /*
		Outpatient services */ CSMPQM@USNA CSMDQM@USNA CSMOQM@USNA /*
		Hospital and nursing home services */ CSMHPQM@USNA CSMHNQM@USNA /*
		Motor vehicle services */ CSTURQM@USNA CSTRLQM@USNA /*
		Public transportation */ CSTIGQM@USNA CSTIPQM@USNA CSTIWQM@USNA /*
		Membership clubs, sports centers, parks, theaters and museums */ CSRCCQM@USNA CSRCPQM@USNA CSRSQM@USNA CSOSLQM@USNA /*
		Audio-video, phographic, and information processing servicse */ CSROTQM@USNA CSRODQM@USNA CSROUQM@USNA CSREEQM@USNA CSROYQM@USNA /*
		Gambling */ CSROGQM@USNA CSROLQM@USNA CSROBQM@USNA /*
		Other recreational services */ CSROVQM@USNA CSRKQM@USNA CSREVQM@USNA /*
		Food services */ CSFPQM@USNA CSFEEQM@USNA /*
		Accommodations */ CSHOTQM@USNA CSHSQM@USNA /*
		Financial services */ CSOBSQM@USNA CSNFCQM@USNA /*
		Insurance */ CSOBIQM@USNA CSLIQM@USNA CSMIQM@USNA CSVIQM@USNA /*
		Communication */ CSLTNQM@USNA CSLPQM@USNA CSRJIQM@USNA /*
		Education services */ CSOEUQM@USNA CSOEEQM@USNA CSEOVQM@USNA /*
		Professional and other services */ CSOBLQM@USNA CSBOQM@USNA CSBOUQM@USNA CSBOPQM@USNA CSOBFQM@USNA /*
		Personal care and clothing services */ CSPPQM@USNA CSOPLQM@USNA /*
		Social services and religious activities */ CSSSCQM@USNA CSSSWQM@USNA CSSSVQM@USNA CSSSRQM@USNA CSSSFQM@USNA /*
		Household maintenance */ CSLDQM@USNA CSLOSQM@USNA CSLORQM@USNA CSLOPQM@USNA CSLOOQM@USNA /*
		Net foreign travel */ CSVTQM@USNA CSVXQM@USNA /*
		Nonprofit */ NPCFQM@USNA /*
		
	Indeces */ /*
		New motor vehicles */ JCDMNM@USNA JCDMTNM@USNA /*
		Net purchases of used motor vehicles */ JCDMUM@USNA JCDMTUM@USNA /*
		Motor vehicle parts and accessories */ JCDMTTM@USNA JCDMTVM@USNA /*
		Furniture and furnishings */ JCDFUM@USNA JCDFOLM@USNA JCDFOFM@USNA JCDFOTM@USNA /*
		Household appliances */ JCDFKKM@USNA JCDFKSM@USNA /*
		Glassware, tableware, and houeshold utensils */ JCDFGDM@USNA JCDFGKM@USNA /*
		Tools and equipment for house and garden */ JCDFSTM@USNA JCDFSLM@USNA /*
		Video, audio, photographic, and information processing equipment and media */ JCDRGDM@USNA JCDOWPM@USNA JCDRGIM@USNA /*
		Sporting equipment, supplies, guns, and ammunition */ JCDRSM@USNA /*
		Sports and recreational vehicles */ JCDOWLM@USNA JCDOWBM@USNA JCDBBM@USNA /*
		Recreational books */ JCDRBM@USNA /*
		Musical instruments */ JCDFTIM@USNA /*
		Jewelry and watches */ JCDOJJM@USNA JCDOJWM@USNA /*
		Therapeutic appliances and equipment */ JCDOOTM@USNA JCDOOEM@USNA /*
		Educational books */ JCDEBM@USNA /*
		Luggage and similar personal items */ JCDOLM@USNA /*
		Telephone and facsimile equipment */ JCDOTM@USNA /*
		Garments */ JCNLFFM@USNA JCNLMFM@USNA JCNLFIM@USNA /*
		Other clothing materials and footwear */ JCNLOLM@USNA JCNLXIM@USNA JCNLSM@USNA /*
		Pharmaceutical and other products */ JCNODRM@USNA JCNODOM@USNA /*
		Recreational items */ JCNOGTM@USNA JCNRPM@USNA JCNGARM@USNA JCNOGFM@USNA /*
		Household supplies */ JCNOLPM@USNA JCNOLFM@USNA JCNOLNM@USNA JCNOLSM@USNA JCNOLOM@USNA /*
		Personal care products */ JCNOPPM@USNA JCNOPCM@USNA JCNOPEM@USNA /*
		Tobacco */ JCNOTM@USNA /*
		Magazines, newspapers, and stationery */ JCNMGM@USNA JCNONM@USNA /*
		Net expenditures abroad by U.S. residents */ JCNOVUM@USNA JCNOVRM@USNA /*
		Housing */ JCSHTM@USNA JCSRDM@USNA JCSHRM@USNA JCSHOM@USNA /*
		Household utilities */ JCSLWSM@USNA JCSLWRM@USNA JCSLEM@USNA JCSLGM@USNA /*
		Outpatient services */ JCSMPM@USNA JCSMDM@USNA JCSMOM@USNA /*
		Hospital and nursing home services */ JCSMHPM@USNA JCSMHNM@USNA /*
		Motor vehicle services */ JCSTURM@USNA JCSTRLM@USNA /*
		Public transportation */ JCSTIGM@USNA JCSTIPM@USNA JCSTIWM@USNA /*
		Membership clubs, sports centers, parks, theaters and museums */ JCSRCCM@USNA JCSRCPM@USNA JCSRSM@USNA JCSOSLM@USNA /*
		Audio-video, phographic, and information processing servicse */ JCSROTM@USNA JCSRODM@USNA JCSROUM@USNA JCSREEM@USNA JCSROYM@USNA /*
		Gambling */ JCSROGM@USNA JCSROLM@USNA JCSROBM@USNA /*
		Other recreational services */ JCSROVM@USNA JCSRKM@USNA JCSREVM@USNA /*
		Food services */ JCSFPM@USNA JCSFEEM@USNA /*
		Accommodations */ JCSHOTM@USNA JCSHSM@USNA /*
		Financial services */ JCSOBSM@USNA JCSNFCM@USNA /*
		Insurance */ JCSOBIM@USNA JCSLIM@USNA JCSMIM@USNA JCSVIM@USNA /*
		Communication */ JCSLTNM@USNA JCSLPM@USNA JCSRJIM@USNA /*
		Education services */ JCSOEUM@USNA JCSOEEM@USNA JCSEOVM@USNA /*
		Professional and other services */ JCSOBLM@USNA JCSBOM@USNA JCSBOUM@USNA JCSBOPM@USNA JCSOBFM@USNA /*
		Personal care and clothing services */ JCSPPM@USNA JCSOPLM@USNA /*
		Social services and religious activities */ JCSSSCM@USNA JCSSSWM@USNA JCSSSVM@USNA JCSSSRM@USNA JCSSSFM@USNA /*
		Household maintenance */ JCSLDM@USNA JCSLOSM@USNA JCSLORM@USNA JCSLOPM@USNA JCSLOOM@USNA /*
		Net foreign travel */ JCSVTM@USNA JCSVXM@USNA /*
	    Nonprofit */ JNPCFM@USNA /*
	   Food and Energy */  /*
		Motor vehicle fuels, lubricants, and fluids */ CNLGOM@USNA CNLGLM@USNA /*
		Motor vehicle fuels, lubricants, and fluids */ JCNLGOM@USNA JCNLGLM@USNA  /*
		Motor vehicle fuels, lubricants, and fluids */ CNLGOQM@USNA CNLGLQM@USNA  /*
		Fuel oil and other fuels */ JCNOFUM@USNA JCNOFLM@USNA  /*
		Fuel oil and other fuels */ CNOFUM@USNA CNOFLM@USNA  /*
		Fuel oil and other fuels */ CNOFUQM@USNA CNOFLQM@USNA  /*
		Food and nonalcoholic beverages */ JCNFOFM@USNA JCNFONM@USNA  /*
		Food and nonalcoholic beverages */ CNFOFM@USNA CNFONM@USNA  /*
		Food and nonalcoholic beverages */ CNFOFQM@USNA CNFONQM@USNA  /*
		Alcoholic beverages */ JCNFOLDM@USNA JCNFOLEM@USNA JCNFOLBM@USNA  /*
		Alcoholic beverages */ CNFOLDM@USNA CNFOLEM@USNA CNFOLBM@USNA  /*
		Alcoholic beverages */ CNFOLDQM@USNA CNFOLEQM@USNA CNFOLBQM@USNA  /*
		Food produced and consumed on farms */ JCNFEFM@USNA  /*
		Food produced and consumed on farms */ CNFEFQM@USNA /*
		Food produced and consumed on farms */ CNFEFM@USNA , tvar(time_month)
}
else if $foodenergy == 0 { 
import haver /*
      */  (GSCPI)@SURVEYS (CM CXFEM JCM JCXFEM YPM YPDM JCGXFEM JCSXEM CGXFEM CSXEM )@USNA  (CSENT LR YPLTPMH FGZEBP FGZCS F10FED SEPUI CCIN FGZPR SP500 F10FED SEPUI CCIN SP500 FFEDTAR FCM10 FCM5 FCM30 FCM3M PZTEXP RECESSM)@USECON (IP CUT)@IP /*
	   Consumption Expenditures */ /* 
		New motor vehicles */ CDMNM@USNA CDMTNM@USNA /*
		Net purchases of used motor vehicles */ CDMUM@USNA CDMTUM@USNA /*
		Motor vehicle parts and accessories */ CDMTTM@USNA CDMTVM@USNA /*
		Furniture and furnishings */ CDFUM@USNA CDFOLM@USNA CDFOFM@USNA CDFOTM@USNA /*
		Household appliances */ CDFKKM@USNA CDFKSM@USNA /*
		Glassware, tableware, and houeshold utensils */ CDFGDM@USNA CDFGKM@USNA /*
		Tools and equipment for house and garden */ CDFSTM@USNA CDFSLM@USNA /*
		Video, audio, photographic, and information processing equipment and media */ CDRGDM@USNA CDOWPM@USNA CDRGIM@USNA /*
		Sporting equipment, supplies, guns, and ammunition */ CDRSM@USNA /*
		Sports and recreational vehicles */ CDOWLM@USNA CDOWBM@USNA CDBBM@USNA /*
		Recreational books */ CDRBM@USNA /*
		Musical instruments */ CDFTIM@USNA /*
		Jewelry and watches */ CDOJJM@USNA CDOJWM@USNA /*
		Therapeutic appliances and equipment */ CDOOTM@USNA CDOOEM@USNA /*
		Educational books */ CDEBM@USNA /*
		Luggage and similar personal items */ CDOLM@USNA /*
		Telephone and facsimile equipment */ CDOTM@USNA /*
		Garments */ CNLFFM@USNA CNLMFM@USNA CNLFIM@USNA /*
		Other clothing materials and footwear */ CNLOLM@USNA CNLXIM@USNA CNLSM@USNA /*
		Pharmaceutical and other products */ CNODRM@USNA CNODOM@USNA /*
		Recreational items */ CNOGTM@USNA CNRPM@USNA CNGARM@USNA CNOGFM@USNA /*
		Household supplies */ CNOLPM@USNA CNOLFM@USNA CNOLNM@USNA CNOLSM@USNA CNOLOM@USNA /*
		Personal care products */ CNOPPM@USNA CNOPCM@USNA CNOPEM@USNA /*
		Tobacco */ CNOTM@USNA /*
		Magazines, newspapers, and stationery */ CNMGM@USNA CNONM@USNA /*
		Net expenditures abroad by U.S. residents */ CNOVUM@USNA CNOVRM@USNA /*
		Housing */ CSHTM@USNA CSRDM@USNA CSHRM@USNA CSHOM@USNA /*
		Household utilities */ CSLWSM@USNA  CSLWRM@USNA /*
		Outpatient services */ CSMPM@USNA CSMDM@USNA CSMOM@USNA /*
		Hospital and nursing home services */ CSMHPM@USNA CSMHNM@USNA /*
		Motor vehicle services */ CSTURM@USNA CSTRLM@USNA /*
		Public transportation */ CSTIGM@USNA CSTIPM@USNA CSTIWM@USNA /*
		Membership clubs, sports centers, parks, theaters and museums */ CSRCCM@USNA CSRCPM@USNA CSRSM@USNA CSOSLM@USNA /*
		Audio-video, phographic, and information processing servicse */ CSROTM@USNA CSRODM@USNA CSROUM@USNA CSREEM@USNA CSROYM@USNA /*
		Gambling */ CSROGM@USNA CSROLM@USNA CSROBM@USNA /*
		Other recreational services */ CSROVM@USNA CSRKM@USNA CSREVM@USNA /*
		Food services */ CSFPM@USNA CSFEEM@USNA /*
		Accommodations */ CSHOTM@USNA CSHSM@USNA /*
		Financial services */ CSOBSM@USNA CSNFCM@USNA /*
		Insurance */ CSOBIM@USNA CSLIM@USNA CSMIM@USNA CSVIM@USNA /*
		Communication */ CSLTNM@USNA CSLPM@USNA CSRJIM@USNA /*
		Education services */ CSOEUM@USNA CSOEEM@USNA CSEOVM@USNA /*
		Professional and other services */ CSOBLM@USNA CSBOM@USNA CSBOUM@USNA CSBOPM@USNA CSOBFM@USNA /*
		Personal care and clothing services */ CSPPM@USNA CSOPLM@USNA /*
		Social services and religious activities */ CSSSCM@USNA CSSSWM@USNA CSSSVM@USNA CSSSRM@USNA CSSSFM@USNA /*
		Household maintenance */ CSLDM@USNA CSLOSM@USNA CSLORM@USNA CSLOPM@USNA CSLOOM@USNA /*
		Net foreign travel */ CSVTM@USNA CSVXM@USNA /*
		Nonprofit */ NPCFM@USNA /*
		
		New motor vehicles */ CDMNQM@USNA CDMTNQM@USNA /*
		Net purchases of used motor vehicles */ CDMUQM@USNA CDMTUQM@USNA /*
		Motor vehicle parts and accessories */ CDMTTQM@USNA CDMTVQM@USNA /*
		Furniture and furnishings */ CDFUQM@USNA CDFOLQM@USNA CDFOFQM@USNA CDFOTQM@USNA /*
		Household appliances */ CDFKKQM@USNA CDFKSQM@USNA /*
		Glassware, tableware, and houeshold utensils */ CDFGDQM@USNA CDFGKQM@USNA /*
		Tools and equipment for house and garden */ CDFSTQM@USNA CDFSLQM@USNA /*
		Video, audio, photographic, and information processing equipment and media */ CDRGDQM@USNA CDOWPQM@USNA CDRGIQM@USNA /*
		Sporting equipment, supplies, guns, and ammunition */ CDRSQM@USNA /*
		Sports and recreational vehicles */ CDOWLQM@USNA CDOWBQM@USNA CDBBQM@USNA /*
		Recreational books */ CDRBQM@USNA /*
		Musical instruments */ CDFTIQM@USNA /*
		Jewelry and watches */ CDOJJQM@USNA CDOJWQM@USNA /*
		Therapeutic appliances and equipment */ CDOOTQM@USNA CDOOEQM@USNA /*
		Educational books */ CDEBQM@USNA /*
		Luggage and similar personal items */ CDOLQM@USNA /*
		Telephone and facsimile equipment */ CDOTQM@USNA /*
		Garments */ CNLFFQM@USNA CNLMFQM@USNA CNLFIQM@USNA /*
		Other clothing materials and footwear */ CNLOLQM@USNA CNLXIQM@USNA CNLSQM@USNA /*
		Pharmaceutical and other products */ CNODRQM@USNA CNODOQM@USNA /*
		Recreational items */ CNOGTQM@USNA CNRPQM@USNA CNGARQM@USNA CNOGFQM@USNA /*
		Household supplies */ CNOLPQM@USNA CNOLFQM@USNA CNOLNQM@USNA CNOLSQM@USNA CNOLOQM@USNA /*
		Personal care products */ CNOPPQM@USNA CNOPCQM@USNA CNOPEQM@USNA /*
		Tobacco */ CNOTQM@USNA /*
		Magazines, newspapers, and stationery */ CNMGQM@USNA CNONQM@USNA /*
		Net expenditures abroad by U.S. residents */ CNOVUQM@USNA CNOVRQM@USNA /*
		Housing */ CSHTQM@USNA CSRDQM@USNA CSHRQM@USNA CSHOQM@USNA /*
		Household utilities */ CSLWSQM@USNA  CSLWRQM@USNA  /*
		Outpatient services */ CSMPQM@USNA CSMDQM@USNA CSMOQM@USNA /*
		Hospital and nursing home services */ CSMHPQM@USNA CSMHNQM@USNA /*
		Motor vehicle services */ CSTURQM@USNA CSTRLQM@USNA /*
		Public transportation */ CSTIGQM@USNA CSTIPQM@USNA CSTIWQM@USNA /*
		Membership clubs, sports centers, parks, theaters and museums */ CSRCCQM@USNA CSRCPQM@USNA CSRSQM@USNA CSOSLQM@USNA /*
		Audio-video, phographic, and information processing servicse */ CSROTQM@USNA CSRODQM@USNA CSROUQM@USNA CSREEQM@USNA CSROYQM@USNA /*
		Gambling */ CSROGQM@USNA CSROLQM@USNA CSROBQM@USNA /*
		Other recreational services */ CSROVQM@USNA CSRKQM@USNA CSREVQM@USNA /*
		Food services */ CSFPQM@USNA CSFEEQM@USNA /*
		Accommodations */ CSHOTQM@USNA CSHSQM@USNA /*
		Financial services */ CSOBSQM@USNA CSNFCQM@USNA /*
		Insurance */ CSOBIQM@USNA CSLIQM@USNA CSMIQM@USNA CSVIQM@USNA /*
		Communication */ CSLTNQM@USNA CSLPQM@USNA CSRJIQM@USNA /*
		Education services */ CSOEUQM@USNA CSOEEQM@USNA CSEOVQM@USNA /*
		Professional and other services */ CSOBLQM@USNA CSBOQM@USNA CSBOUQM@USNA CSBOPQM@USNA CSOBFQM@USNA /*
		Personal care and clothing services */ CSPPQM@USNA CSOPLQM@USNA /*
		Social services and religious activities */ CSSSCQM@USNA CSSSWQM@USNA CSSSVQM@USNA CSSSRQM@USNA CSSSFQM@USNA /*
		Household maintenance */ CSLDQM@USNA CSLOSQM@USNA CSLORQM@USNA CSLOPQM@USNA CSLOOQM@USNA /*
		Net foreign travel */ CSVTQM@USNA CSVXQM@USNA /*
		Nonprofit */ NPCFQM@USNA /*
		
	Indeces */ /*
		New motor vehicles */ JCDMNM@USNA JCDMTNM@USNA /*
		Net purchases of used motor vehicles */ JCDMUM@USNA JCDMTUM@USNA /*
		Motor vehicle parts and accessories */ JCDMTTM@USNA JCDMTVM@USNA /*
		Furniture and furnishings */ JCDFUM@USNA JCDFOLM@USNA JCDFOFM@USNA JCDFOTM@USNA /*
		Household appliances */ JCDFKKM@USNA JCDFKSM@USNA /*
		Glassware, tableware, and houeshold utensils */ JCDFGDM@USNA JCDFGKM@USNA /*
		Tools and equipment for house and garden */ JCDFSTM@USNA JCDFSLM@USNA /*
		Video, audio, photographic, and information processing equipment and media */ JCDRGDM@USNA JCDOWPM@USNA JCDRGIM@USNA /*
		Sporting equipment, supplies, guns, and ammunition */ JCDRSM@USNA /*
		Sports and recreational vehicles */ JCDOWLM@USNA JCDOWBM@USNA JCDBBM@USNA /*
		Recreational books */ JCDRBM@USNA /*
		Musical instruments */ JCDFTIM@USNA /*
		Jewelry and watches */ JCDOJJM@USNA JCDOJWM@USNA /*
		Therapeutic appliances and equipment */ JCDOOTM@USNA JCDOOEM@USNA /*
		Educational books */ JCDEBM@USNA /*
		Luggage and similar personal items */ JCDOLM@USNA /*
		Telephone and facsimile equipment */ JCDOTM@USNA /*
		Garments */ JCNLFFM@USNA JCNLMFM@USNA JCNLFIM@USNA /*
		Other clothing materials and footwear */ JCNLOLM@USNA JCNLXIM@USNA JCNLSM@USNA /*
		Pharmaceutical and other products */ JCNODRM@USNA JCNODOM@USNA /*
		Recreational items */ JCNOGTM@USNA JCNRPM@USNA JCNGARM@USNA JCNOGFM@USNA /*
		Household supplies */ JCNOLPM@USNA JCNOLFM@USNA JCNOLNM@USNA JCNOLSM@USNA JCNOLOM@USNA /*
		Personal care products */ JCNOPPM@USNA JCNOPCM@USNA JCNOPEM@USNA /*
		Tobacco */ JCNOTM@USNA /*
		Magazines, newspapers, and stationery */ JCNMGM@USNA JCNONM@USNA /*
		Net expenditures abroad by U.S. residents */ JCNOVUM@USNA JCNOVRM@USNA /*
		Housing */ JCSHTM@USNA JCSRDM@USNA JCSHRM@USNA JCSHOM@USNA /*
		Household utilities */ JCSLWSM@USNA  JCSLWRM@USNA /*
		Outpatient services */ JCSMPM@USNA JCSMDM@USNA JCSMOM@USNA /*
		Hospital and nursing home services */ JCSMHPM@USNA JCSMHNM@USNA /*
		Motor vehicle services */ JCSTURM@USNA JCSTRLM@USNA /*
		Public transportation */ JCSTIGM@USNA JCSTIPM@USNA JCSTIWM@USNA /*
		Membership clubs, sports centers, parks, theaters and museums */ JCSRCCM@USNA JCSRCPM@USNA JCSRSM@USNA JCSOSLM@USNA /*
		Audio-video, phographic, and information processing servicse */ JCSROTM@USNA JCSRODM@USNA JCSROUM@USNA JCSREEM@USNA JCSROYM@USNA /*
		Gambling */ JCSROGM@USNA JCSROLM@USNA JCSROBM@USNA /*
		Other recreational services */ JCSROVM@USNA JCSRKM@USNA JCSREVM@USNA /*
		Food services */ JCSFPM@USNA JCSFEEM@USNA /*
		Accommodations */ JCSHOTM@USNA JCSHSM@USNA /*
		Financial services */ JCSOBSM@USNA JCSNFCM@USNA /*
		Insurance */ JCSOBIM@USNA JCSLIM@USNA JCSMIM@USNA JCSVIM@USNA /*
		Communication */ JCSLTNM@USNA JCSLPM@USNA JCSRJIM@USNA /*
		Education services */ JCSOEUM@USNA JCSOEEM@USNA JCSEOVM@USNA /*
		Professional and other services */ JCSOBLM@USNA JCSBOM@USNA JCSBOUM@USNA JCSBOPM@USNA JCSOBFM@USNA /*
		Personal care and clothing services */ JCSPPM@USNA JCSOPLM@USNA /*
		Social services and religious activities */ JCSSSCM@USNA JCSSSWM@USNA JCSSSVM@USNA JCSSSRM@USNA JCSSSFM@USNA /*
		Household maintenance */ JCSLDM@USNA JCSLOSM@USNA JCSLORM@USNA JCSLOPM@USNA JCSLOOM@USNA /*
		Net foreign travel */ JCSVTM@USNA JCSVXM@USNA /*
        Nonprofit */ JNPCFM@USNA, tvar(time_month) 
		}
}



gen year        = year(dofm(time_month))
gen month       = month(dofm(time_month))
gen quarter     = quarter(dofm(time_month))
rename cm_usna         pce_spend
rename jcm_usna        pce
rename jcxfem_usna     core
rename cxfem_usna      core_spend
rename jcgxfem_usna core_goods
rename jcsxem_usna  core_serv 
rename cgxfem_usna  core_goods_spend
rename csxem_usna   core_serv_spend 
rename jc*_usna *
rename c*qm_usna *m_quant
rename c*_usna *_spend

rename jnpcfm_usna  pcfm
rename npcfm_usna   pcfm_spend
rename npcfqm_usna  pcfm_quant


cap replace svxm_spend = -svxm_spend
cap replace novrm_spend = -novrm_spend 
order time_month pce core pce_spend core_goods core_serv core_goods_spend core_serv_spend  

drop if missing(core)
tsset time_month
local dater time_month
local window 120

if ($level == 0 |$level == 1) {
keep if year > 1958
}


if $level == 2 {
keep if year > 1987
}


******QUARTERLY********
if $quarterly == 1 {
preserve
collapse (sum) FF1-ONRUN30, by(time_quarter)
rename * *_sum
rename time_quarter_sum time_quarter
tempfile temps
sort time_quarter
save `temps',replace
restore
order time_month pce core nairu PTR
collapse (mean) pce-BHshock, by(time_quarter)
sort time_quarter
merge 1:1 time_quarter using `temps', nogen
tsset time_quarter	
replace usrec = 1 if usrec > 0	
local dater time_quarter
local window 40
}


*Annualized monthly
if $level == 0 {
local start dfdm
}

if $level == 1 {
local start dbbm
}

if $level == 2 {
local start dbbm
}


if $firstdiff == 0 {
foreach i of varlist util IP core pce core_goods core_serv `start'-pcfm { 
qui gen `i'_m     = (`i' - l.`i')/l.`i'
qui gen `i'_plev = ln(`i') /*run regression in logs*/
replace `i' = `i'_m
drop `i'_m
}

foreach i of varlist `start'-pcfm { 
replace `i'_quant = ln(`i'_quant) /*run regression in logs*/
}
}


if $firstdiff == 1 {
foreach i of varlist util IP core pce core_goods core_serv `start'-pcfm { 
tsset time_month
qui gen `i'_m     = (`i' - l.`i')/l.`i'
qui gen `i'_plev = ln(`i'/l.`i')  /*run regression in first differences*/
replace `i' = `i'_m
drop `i'_m
}

foreach i of varlist `start'-pcfm { 
gen `i'_quant_temp = `i'_quant
drop `i'_quant
gen `i'_quant = ln(`i'_quant_temp/l.`i'_quant_temp) /*run regression in  first differences*/
}


}

if $trend == 0 {
gen trend  = 0
gen trend2 = 0
gen trend3 = 0
}


if $quarterly == 1{ 
if $trend == 1 {
gen trend  = time_month
gen trend2 = time_month^2
gen trend3 = time_month^3
}	
}

if $quarterly == 0{ 
if $trend == 1 {
gen trend = time_quarter
gen trend2 = time_quarter^2
gen trend3 = time_quarter^3
}	
}


tsset `dater' 
if $quarterly == 0 {
sum `dater'  if `dater'  >= tm(`min_date')
}

if $quarterly == 1 {
sum `dater'  if `dater'  >= tq(`min_date')
}

local first = r(min)
local last  = r(max)

local lagc = $cumul + $lag - 1


***Hamilton (2018) Filter***
if $hamilton == 1 {
foreach i of varlist `start'-pcfm { 
qui reg `i'_quant l(24/36).`i'_quant 
qui predict `i'_qham, resid
qui replace `i'_quant = `i'_qham
qui reg `i'_plev l(24/36).`i'_plev 
qui predict `i'_pham, resid
qui replace `i'_plev = `i'_pham
qui drop `i'_pham  `i'_qham
}
}	
	
********Rolling Regressions**************
forval event_dum = `first'(1)`last' {
preserve
gen event  = `dater'  ==  `event_dum'
gen ignore = `dater'  < (`event_dum' - `window') | `dater'  > `event_dum' 
gen temp = 0
foreach i of varlist `start'-pcfm { 
qui reg `i'_quant l($cumul/`lagc').`i'_quant l($cumul/`lagc').`i'_plev   trend*       if ignore == 0    
qui predict `i'_uq, resid
if $smooth == 3 {
qui gen test = `i'_uq + l.`i'_uq + l2.`i'_uq
qui replace `i'_uq = test
qui drop test
}
if $smooth == 2 {
qui gen test = `i'_uq + l.`i'_uq 
qui replace `i'_uq = test
qui drop test
}
if $smooth == 4 {
qui gen test = `i'_uq + l.`i'_uq + l2.`i'_uq + l3.`i'_uq
qui replace `i'_uq = test
qui drop test
}
*************
qui sum `i'_uq  if ignore == 0 
qui gen t = `i'_uq/r(sd)
qui sum t if `dater'  == `event_dum' 
local `i'_t = r(mean)
qui drop t
qui reg `i'_plev l($cumul/`lagc').`i'_quant l($cumul/`lagc').`i'_plev  trend*             if ignore == 0    
qui predict `i'_up, resid
if $smooth == 3 {
qui gen test = `i'_up + l.`i'_up + l2.`i'_up
qui replace `i'_up = test
qui drop test
}  
if $smooth == 2 {
qui gen test = `i'_up + l.`i'_up 
qui replace `i'_up = test
qui drop test
}  
if $smooth == 4 {
qui gen test = `i'_up + l.`i'_up + l2.`i'_up + l3.`i'_up
qui replace `i'_up = test
qui drop test
}  
*************
qui sum `i'_up  if ignore == 0 
qui gen t = `i'_up/r(sd)
qui sum t if `dater'  == `event_dum' 
local `i'_t2 = r(mean)
if $weight == 1 {
qui gen lambda_`i' = `i'_up*`i'_uq
qui sum lambda_`i' if ignore == 0 
gen `i'_tlambda  = lambda_`i'/r(sd)
gen `i'_weightD = t((r(N)-2),`i'_tlambda) /*one tail probability is the weight*/
gen `i'_weightS = 1 -`i'_weightD  /*one tail probability is the weight*/
}
qui drop  `i'_up `i'_uq t
}


if $foodenergy == 0 {
foreach i of varlist `start'-pcfm { 
local demdumHH_`i'   =  ((``i'_t' <   -`thresh3')  &  (``i'_t2' <   -`thresh3')) | ((``i'_t' >   `thresh3')  &  (``i'_t2' >   `thresh3')) 
local demdumH_`i'    =  (((``i'_t' <   -`thresh2')  &  (``i'_t2' <   -`thresh2')) | ((``i'_t' >   `thresh2')  &  (``i'_t2' >   `thresh2')))  & (`demdumHH_`i'' == 0)
local demdumL_`i'    =  (((``i'_t' <   -$thresh1) &  (``i'_t2' <   -$thresh1)) | ((``i'_t' >   $thresh1)  &  (``i'_t2' >   $thresh1))) & (`demdumH_`i'' == 0) & (`demdumHH_`i'' == 0)
local demdum_`i'    =   `demdumHH_`i'' == 1 | `demdumH_`i'' == 1 | `demdumL_`i'' == 1
qui gen demdum_`i' = 0
qui replace demdum_`i' = `demdum_`i'' if `dater'  ==  `event_dum'
local supdumHH_`i'    =  ((``i'_t' <   -`thresh3')  &  (``i'_t2' >    `thresh3')) | ((``i'_t' >   `thresh3')  &  (``i'_t2' <   -`thresh3'))
local supdumH_`i'    =  (((``i'_t' <   -`thresh2')  &  (``i'_t2' >    `thresh2')) | ((``i'_t' >   `thresh2')  &  (``i'_t2' <   -`thresh2')))   & (`supdumHH_`i'' == 0)
local supdumL_`i'    =  (((``i'_t' <   -$thresh1)  &  (``i'_t2' >    $thresh1)) | ((``i'_t' >   $thresh1)  &  (``i'_t2' <   -$thresh1))) & (`supdumH_`i'' == 0) & (`supdumHH_`i'' == 0)
local supdum_`i'    =   `supdumHH_`i'' == 1 | `supdumH_`i'' == 1 | `supdumL_`i'' == 1
qui gen supdum_`i' = 0
qui replace supdum_`i' = `supdum_`i'' if `dater'  ==  `event_dum'
local ambdum_`i'    = `demdumHH_`i'' == 0 & `supdumHH_`i'' == 0 & `demdumH_`i'' == 0 & `supdumH_`i'' == 0 & `demdumL_`i'' == 0 & `supdumL_`i'' == 0 

local  demdumP_`i' =  (`demdum_`i'' == 1) & (``i'_t2' >  0)
local  demdumN_`i' =  (`demdum_`i'' == 1) & (``i'_t2' <= 0)
local  supdumP_`i' =  (`supdum_`i'' == 1) & (``i'_t2' <  0)
local  supdumN_`i' =  (`supdum_`i'' == 1) & (``i'_t2' >= 0)

qui gen   contr_`i'm    = (l.`i'_spend/l.core_spend)*`i'
qui gen   weight_`i'm = (l.`i'_spend/l.core_spend)
}
}


if $foodenergy == 1 {
foreach i of varlist `start'-pcfm { 
local demdumHH_`i'   =  ((``i'_t' <   -`thresh3')  &  (``i'_t2' <   -`thresh3')) | ((``i'_t' >   `thresh3')  &  (``i'_t2' >   `thresh3')) 
local demdumH_`i'    =  (((``i'_t' <   -`thresh2')  &  (``i'_t2' <   -`thresh2')) | ((``i'_t' >   `thresh2')  &  (``i'_t2' >   `thresh2')))  & (`demdumHH_`i'' == 0)
local demdumL_`i'    =  (((``i'_t' <   -$thresh1) &  (``i'_t2' <   -$thresh1)) | ((``i'_t' >   $thresh1)  &  (``i'_t2' >   $thresh1))) & (`demdumH_`i'' == 0) & (`demdumHH_`i'' == 0)
local demdum_`i'    =   `demdumHH_`i'' == 1 | `demdumH_`i'' == 1 | `demdumL_`i'' == 1
qui gen demdum_`i' = 0
qui replace demdum_`i' = `demdum_`i'' if `dater'  ==  `event_dum'
local supdumHH_`i'    =  ((``i'_t' <   -`thresh3')  &  (``i'_t2' >    `thresh3')) | ((``i'_t' >   `thresh3')  &  (``i'_t2' <   -`thresh3'))
local supdumH_`i'    =  (((``i'_t' <   -`thresh2')  &  (``i'_t2' >    `thresh2')) | ((``i'_t' >   `thresh2')  &  (``i'_t2' <   -`thresh2')))   & (`supdumHH_`i'' == 0)
local supdumL_`i'    =  (((``i'_t' <   -$thresh1)  &  (``i'_t2' >    $thresh1)) | ((``i'_t' >   $thresh1)  &  (``i'_t2' <   -$thresh1))) & (`supdumH_`i'' == 0) & (`supdumHH_`i'' == 0)
local supdum_`i'    =   `supdumHH_`i'' == 1 | `supdumH_`i'' == 1 | `supdumL_`i'' == 1
qui gen supdum_`i' = 0
qui replace supdum_`i' = `supdum_`i'' if `dater'  ==  `event_dum'
local ambdum_`i'    = `demdumHH_`i'' == 0 & `supdumHH_`i'' == 0 & `demdumH_`i'' == 0 & `supdumH_`i'' == 0 & `demdumL_`i'' == 0 & `supdumL_`i'' == 0 

local  demdumP_`i' =  (`demdum_`i'' == 1) & (``i'_t2' >  0)
local  demdumN_`i' =  (`demdum_`i'' == 1) & (``i'_t2' <= 0)
local  supdumP_`i' =  (`supdum_`i'' == 1) & (``i'_t2' <  0)
local  supdumN_`i' =  (`supdum_`i'' == 1) & (``i'_t2' >= 0)

qui gen   contr_`i'm    = (l.`i'_spend/l.pce_spend)*`i'
qui gen   weight_`i'm  = (l.`i'_spend/l.pce_spend)
}
}


*Construct Supply and Demand Contributions to Inflation
qui gen demHH_contr_m = 0
qui gen demH_contr_m = 0
qui gen demL_contr_m = 0
qui gen supH_contr_m = 0
qui gen supHH_contr_m = 0
qui gen supL_contr_m = 0
qui gen amb_contr_m = 0
qui gen demP_contr_m = 0
qui gen demN_contr_m = 0
qui gen supP_contr_m = 0
qui gen supN_contr_m = 0


foreach i of varlist `start'-pcfm {
replace demHH_contr_m = demHH_contr_m + contr_`i'm*`demdumHH_`i''
replace demH_contr_m = demH_contr_m + contr_`i'm*`demdumH_`i''
replace demL_contr_m = demL_contr_m + contr_`i'm*`demdumL_`i''
replace supHH_contr_m = supHH_contr_m + contr_`i'm*`supdumHH_`i''
replace supH_contr_m = supH_contr_m + contr_`i'm*`supdumH_`i''
replace supL_contr_m = supL_contr_m + contr_`i'm*`supdumL_`i''
replace amb_contr_m = amb_contr_m + contr_`i'm*`ambdum_`i''
replace demP_contr_m = demP_contr_m + contr_`i'm*`demdumP_`i''
replace demN_contr_m = demN_contr_m + contr_`i'm*`demdumN_`i''
replace supP_contr_m = supP_contr_m + contr_`i'm*`supdumP_`i''
replace supN_contr_m = supN_contr_m + contr_`i'm*`supdumN_`i''
}


if $weight ==  0 {
gen dem_contr_m =  demHH_contr_m +  demH_contr_m +  demL_contr_m
gen sup_contr_m =  supHH_contr_m +  supH_contr_m +  supL_contr_m
}

if $weight == 1 {
qui gen dem_contr_m = 0
qui gen sup_contr_m = 0
foreach i of varlist `start'-pcfm {
replace dem_contr_m = dem_contr_m + contr_`i'm*`i'_weightD
replace sup_contr_m = sup_contr_m + contr_`i'm*`i'_weightS
}
}


*Construct information about shocks
qui gen share_dempos = 0
qui gen share_demneg = 0
qui gen share_suppos = 0
qui gen share_supneg = 0
qui gen num_dempos = 0
qui gen num_demneg = 0
qui gen num_suppos = 0
qui gen num_supneg = 0

if $level == 2 {
if $foodenergy == 1 {
local k = 136
}

if $foodenergy == 0 {
local k = 124
} 
}

if $level == 1 {
if $foodenergy == 1 {
local k = 129
}

if $foodenergy == 0 {
local k = 117
} 
}


foreach i of varlist `start'-pcfm {
replace share_dempos = share_dempos + `demdum_`i''*(``i'_t2' > 0)*weight_`i'm 
replace share_demneg = share_demneg + `demdum_`i''*(``i'_t2' < 0)*weight_`i'm 
replace share_suppos = share_suppos + `supdum_`i''*(``i'_t2' < 0)*weight_`i'm 
replace share_supneg = share_supneg + `supdum_`i''*(``i'_t2' > 0)*weight_`i'm 
replace num_dempos = num_dempos + `demdum_`i''*(``i'_t2' > 0)*(1/`k')
replace num_demneg = num_demneg + `demdum_`i''*(``i'_t2' < 0)*(1/`k')
replace num_suppos = num_suppos + `supdum_`i''*(``i'_t2' < 0)*(1/`k')
replace num_supneg = num_supneg + `supdum_`i''*(``i'_t2' > 0)*(1/`k')
}

*****Construct inflation rates****
gen dem_spend = 0
gen sup_spend = 0
gen dem_inf_m = 0
gen sup_inf_m = 0 

foreach i of varlist `start'-pcfm { 
qui replace dem_spend = dem_spend + `demdum_`i''*`i'_spend
qui replace sup_spend = sup_spend + `supdum_`i''*`i'_spend
}
if $foodenergy == 1 {
gen tot_spend = dem_spend + sup_spend
qui replace dem_spend = (dem_spend/tot_spend)*pce_spend
qui replace sup_spend = (sup_spend/tot_spend)*pce_spend
}
if $foodenergy == 0 {
gen tot_spend = dem_spend + sup_spend
qui replace dem_spend = (dem_spend/tot_spend)*core_spend
qui replace sup_spend = (sup_spend/tot_spend)*core_spend
}

foreach i of varlist `start'-pcfm { 
qui gen   contrdem_`i'm    = (l.`i'_spend/l.dem_spend)*`i'
qui gen   contrsup_`i'm    = (l.`i'_spend/l.sup_spend)*`i'
}
foreach i of varlist `start'-pcfm { 
replace dem_inf_m = dem_inf_m + contrdem_`i'm*`demdum_`i''
replace sup_inf_m = sup_inf_m + contrsup_`i'm*`supdum_`i''
}

qui drop contrdem_*  contrsup_* tot_spend

label variable demHH_contr_m  "Very Likely Demand-driven PCE contribution"
label variable demH_contr_m  "Likely Demand-driven PCE contribution"
label variable demL_contr_m  "Possibly Demand-driven PCE contribution"
label variable supHH_contr_m  "Very Likely Supply-driven PCE contribution"
label variable supH_contr_m  "Likely Supply-driven PCE contribution"
label variable supL_contr_m  "Possibly Supply-driven PCE contribution"
label variable amb_contr_m  "Ambiguous PCE contribution"

keep if `dater'  ==  `event_dum'
tempfile event_`event_dum'
save `event_`event_dum'', replace
restore
}
clear all
use `event_`first'', clear
local k = `first'+1
forval i = `k'/`last' {
append using `event_`i''
}

*drop if missing(amb_contr_m)

*Construct year-over-year contributions
gen demHH_contr_y = 1
gen demH_contr_y = 1
gen demL_contr_y = 1
gen supHH_contr_y = 1
gen supH_contr_y = 1
gen supL_contr_y = 1
gen amb_contr_y = 1
qui gen demP_contr_y = 1
qui gen demN_contr_y = 1
qui gen supP_contr_y = 1
qui gen supN_contr_y = 1



if $quarterly == 0 {
tsset time_month
local end  11 
local end2 12
local tsseter time_month
}

if $quarterly == 1 {
tsset time_quarter
local end 3 
local end2 4
local tsseter time_quarter
}



forval i = 0/`end' {
replace demHH_contr_y = (1+l`i'.demHH_contr_m)*demHH_contr_y
replace demH_contr_y = (1+ l`i'.demH_contr_m)*demH_contr_y
replace demL_contr_y = (1+l`i'.demL_contr_m)*demL_contr_y
replace supHH_contr_y = (1+l`i'.supHH_contr_m)*supHH_contr_y
replace supH_contr_y = (1+l`i'.supH_contr_m)*supH_contr_y
replace supL_contr_y = (1+l`i'.supL_contr_m)*supL_contr_y
replace amb_contr_y = (1+l`i'.amb_contr_m)*amb_contr_y
replace demP_contr_y = (1+l`i'.demP_contr_m)*demP_contr_y
replace demN_contr_y = (1+l`i'.demN_contr_m)*demN_contr_y
replace supP_contr_y = (1+l`i'.supP_contr_m)*supP_contr_y
replace supN_contr_y = (1+l`i'.supN_contr_m)*supN_contr_y
tsset `tsseter'
}

replace demHH_contr_y = demHH_contr_y - 1
replace demH_contr_y = demH_contr_y - 1
replace demL_contr_y = demL_contr_y - 1
replace supHH_contr_y = supHH_contr_y  - 1
replace supH_contr_y = supH_contr_y - 1
replace supL_contr_y = supL_contr_y - 1
replace amb_contr_y = amb_contr_y - 1
replace demP_contr_y = demP_contr_y - 1
replace demN_contr_y = demN_contr_y - 1
replace supP_contr_y = supP_contr_y - 1
replace supN_contr_y = supN_contr_y - 1


gen dem_contr_y =  demHH_contr_y +  demH_contr_y +  demL_contr_y
gen sup_contr_y =  supHH_contr_y +  supH_contr_y +  supL_contr_y

replace demHH_contr_y = 100*demHH_contr_y
replace demH_contr_y = 100*demH_contr_y
replace demL_contr_y = 100*demL_contr_y
replace dem_contr_y = 100*dem_contr_y
replace supHH_contr_y = 100*supHH_contr_y
replace supH_contr_y = 100*supH_contr_y
replace supL_contr_y = 100*supL_contr_y
replace sup_contr_y = 100*sup_contr_y
replace amb_contr_y = 100*amb_contr_y
replace demP_contr_y = 100*demP_contr_y
replace demN_contr_y = 100*demN_contr_y
replace supP_contr_y = 100*supP_contr_y
replace supN_contr_y = 100*supN_contr_y



*Annualize monthly rates
gen  demHH_contr_m_na = demHH_contr_m
gen  demH_contr_m_na = demH_contr_m
gen  demL_contr_m_na = demL_contr_m
gen  dem_contr_m_na = dem_contr_m
gen  supHH_contr_m_na = supHH_contr_m
gen  supH_contr_m_na = supH_contr_m
gen  supL_contr_m_na = supL_contr_m
gen  sup_contr_m_na = sup_contr_m
gen  demP_contr_m_na = demP_contr_m
gen  demN_contr_m_na = demN_contr_m
gen  supP_contr_m_na = supP_contr_m
gen  supN_contr_m_na = supN_contr_m

gen  amb_contr_m_na = amb_contr_m
replace demHH_contr_m =  ((demHH_contr_m + 1)^`end2' - 1)*100
replace demH_contr_m =  ((demH_contr_m + 1)^`end2' - 1)*100
replace demL_contr_m =  ((demL_contr_m + 1)^`end2' - 1)*100
replace dem_contr_m =  ((dem_contr_m + 1)^`end2' - 1)*100
replace demP_contr_m =  ((demP_contr_m + 1)^`end2' - 1)*100
replace demN_contr_m =  ((demN_contr_m + 1)^`end2' - 1)*100

replace amb_contr_m  = ((amb_contr_m + 1)^`end2' - 1)*100
replace supHH_contr_m  = ((supHH_contr_m + 1)^`end2' - 1)*100
replace supH_contr_m  = ((supH_contr_m + 1)^`end2' - 1)*100
replace supL_contr_m  = ((supL_contr_m + 1)^`end2' - 1)*100
replace sup_contr_m  = ((sup_contr_m + 1)^`end2' - 1)*100
replace supP_contr_m  = ((supP_contr_m + 1)^`end2' - 1)*100
replace supN_contr_m  = ((supN_contr_m + 1)^`end2' - 1)*100


gen dem_inf_y = 1
gen sup_inf_y = 1 

*Construct inflation rates
forval i = 0/`end' {
replace dem_inf_y = (1+ l`i'.dem_inf_m)*dem_inf_y
replace sup_inf_y = (1+ l`i'.sup_inf_m)*sup_inf_y
tsset `tsseter'
}

replace dem_inf_y = dem_inf_y - 1
replace sup_inf_y = sup_inf_y - 1
replace dem_inf_y = 100*dem_inf_y
replace sup_inf_y = 100*sup_inf_y 

gen dem_inf_m_na = dem_inf_m*100
gen sup_inf_m_na = sup_inf_m*100

*Annualize monthly rates
replace dem_inf_m =  ((dem_inf_m + 1)^`end2' - 1)*100
replace sup_inf_m  = ((sup_inf_m + 1)^`end2' - 1)*100


if $quarterly == 0 {
tostring(month), gen(month_st)
tostring(year), gen(year_st)
gen time = year_st + "m" + month_st
gen zero = 0
labmask time_month, values(time) /*need to ssc install labutil*/
}



if $quarterly == 1 {
tostring(quarter), gen(quarter_st)
tostring(year), gen(year_st)
gen time = year_st + "q" + quarter_st
gen zero = 0
labmask time_quarter, values(time) /*need to ssc install labutil*/
}


