****************README************************
"Decomposing Supply and Demand Driven Inflation"
Adam Hale Shapiro, Federal Reserve Bank of San Francisco 

Code requires Haver, which is used to download the PCE price and quantity indexes
Users who don't have Haver can download the data off the BEA website.


- main.do is the wrapper that calls "main_construct.do"
        User can choose settings of programs using the globals:
	
	Baseline Headline settings:
	global foodenergy = 0
	global smooth     = 0
	global thresh1    = 0
	global lag        = 12
	global weight     = 0
	global firstdiff  = 0
	global level      = 1
	global trend      = 0
	global cumul      = 1
	global quarterly  = 0
	global hamilton   = 0 


	$foodenergy defines headline or core inflation   (choices restricted to 0,1)    
			  = 1 is headline
                  	  = 0 is core 

	$smooth defines labels based on a smoothed residual (choices restricted to 0,2,3,4)
                  	  = 0 is baseline (no smoothing)
                          = 2 means the current and lagged residual are averaged
                          = 3 means the current and 2 lagged residuals are averaged 
                          = 4 means the current and 3 lagged residuals are averaged 

        $thresh1 defines the threshold to set the "ambiguous" group (can set between 0 and 0.15)
			  = 0 is baseline (no ambiguous category)
                          = 0.1 is threshold set in paper (Figure 5)

	$lag defines how many lags to include in VAR
			  = 12 is baseline
  
        $weight defines the use of the parametric distribution to weight categories (see paper's appendix)
		          = 0 is baseline
                          = 1 is parametric weights

	$firstdiff defines the VAR to be in first-differences (choices restricted to 0,1), see equations (19) and (20) of paper    
		         = 0 is baseline
                         = 1 is first-differences 

	$level defines the level of aggregation of BEA's categories (choices restricted to 0, 1, 2)
		         = 1 is baseline
                         = 0 is top-level BEA aggregation
                         = 2 is more granular aggregation (data only available to 1988) 

	$trend includes a 3rd order polynomial trend in the VAR (choices restricted to 0,1)
			 = 0 is baseline (no trend)
                         = 1 is with trend

	$cumul  defines the distance of the impulse response horizon (h) in the VAR, see equations (17) and (18) of paper (unrestricted choice set)
			= 1 is baseline 

	$quarterly defines aggregation of frequency (choices restricted to 0,1)
			 = 0 is monthly (baseline)
			 = 1 is quarterly

	$hamilton includes the Hamilton (2018) filter before running estimation (choices restricted to 0,1)
			= 0 baseline (no filter)
			= 1 is no filter


-





	
                                



        
            